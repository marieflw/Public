
<?php
include("inc/header.php")
?>



<div class="container my-5 py-5 z-depth-1">
 

        <!--Section: Content-->
        <section class="text-center px-md-5 mx-md-5 dark-grey-text">
    
          <!--Grid row-->
          <div class="row d-flex justify-content-center">
    
            <!--Grid column-->
            <div class="col-lg-7">
               <h2>VOUS ÊTES PROFESSIONNEL ?</h2>
              <p>Pas encore marchand sur Easyquete?
                    Vous pouvez contacter notre service commercial par e-mail sur l'adresse contact@easyquete.com et nous vous aiderons à ouvrir votre compte. Vous pouvez aussi directement compléter ce formulaire : </p>
    
            </div>
            <!--Grid column-->
    
          </div>
          <!--Grid row-->
        </section>
        <!--Section: Content-->
    
    
      </div>
 



<!--form-->
<div class="container my-5">

        <style>
        .border-top {
          border-top: 5px solid #33b5e5 !important;
          border-top-left-radius: .25rem!important;
            border-top-right-radius: .25rem!important;
        }
      </style>
    
      <!--Section: Content-->
      <section class="text-center dark-grey-text mb-5">
    
        <div class="card">
          <div class="card-body rounded-top border-top p-5">
            
          
    
            <form class="mb-4 mx-md-5" method="POST" action="traitement.php" name="content">


            
    
              <div class="row">
                <div class="col-md-6 mb-4">
    
                  <!-- Nom -->
                  <input type="text" id="nom" name="nom" class="form-control" placeholder="Nom">
    
                </div>

                <div class="col-md-6 mb-4">
    
                        <!-- Prénom -->
                        <input type="text" id="prenom" name="prenom" class="form-control" placeholder="Prénom">
          
                      </div>
                <div class="col-md-6 mb-4">
    
                  <!-- Email -->
                  <input type="email" id="email" name="email" class="form-control" placeholder="Email">
    
                </div>

            
                      <div class="col-md-6 mb-4">
    
                            <!-- Téléphone -->
                            <input type="tel" id="tel" name="tel" class="form-control" placeholder="Téléphone">
              
                          </div>
                         
              </div>
    
              <div class="row">
                <div class="col-md-12 mb-4">
    
                  <!-- Subject -->
                  <input type="text" id="addsc" name="addsc" class="form-control" placeholder="Adresse de la société">
    
                </div>

                <div class="col-md-6 mb-4">
    
                        <!-- pays -->
                        <input type="Text" id="pays" name="pays" class="form-control" placeholder="Pays">
          
                      </div>

                      <div class="col-md-6 mb-4">
    
                            <!-- code postal -->
                            <input type="Text" id="Cpostal" name="Cpostal" class="form-control" placeholder="Code postal">
              
                          </div>

                          <div class="col-md-6 mb-4">
    
                                <!-- N° Société-->
                                <input type="text" id="Nsoc" name="Nsoc" class="form-control" placeholder="N° Société">
                  
                              </div>

                              <div class="col-md-6 mb-4">
    
                                    <!-- Statut légal -->
                                    <input type="text" id="statutl" name="statutl" class="form-control" placeholder="Statut Légal">
                      
                                  </div>

                                  <div class="col-md-6 mb-4">
    
                                        <!-- N° Siret -->
                                        <input type="text" id="N° Siret" name="siret" class="form-control" placeholder="N° Siret">
                          
                                      </div>

                                      <div class="col-md-6 mb-4">
    
                                            <!-- RCS -->
                                            <input type="text" id="RCS" name="rcs" class="form-control" placeholder="RCS">
                              
                                          </div>


              </div>

              <div class="row">
                <div class="col-md-12">
    
                  <div class="form-group mb-4">
                    <textarea class="form-control rounded" id="message" name="message" rows="3" placeholder="Votre message."></textarea>
                  </div>
    
                </div>
              </div>
    
              

              <button type="submit" class="btn btn-primary minscri" data-toggle="modal" data-target="#centralModalSuccess" style="margin-bottom: -720px;z-index: 2;"> je m'inscris</button>

                              <!-- Central Modal Medium Success -->
                              <div class="modal fade" id="centralModalSuccess" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                                aria-hidden="true">
                                <div class="modal-dialog modal-notify modal-success" role="document">
                                  <!--Content-->
                                  <div class="modal-content">
                                    <!--Header-->
                                    <div class="modal-header">
                                      <p class="heading lead">Inscription partenaire EasyQuete</p>

                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true" class="white-text">&times;</span>
                                      </button>
                                    </div>

                                    <!--Body-->
                                    <div class="modal-body">
                                      <div class="text-center">
                                        <i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
                                        <p>Votre inscription en tant que partenaire EasyQuete a bien été prise en compte. Nous traitons votre demande dans les plus bref délais et nous vous recontacterons . </p>
                                      </div>
                                    </div>

                                    <!--Footer-->
                                    <div class="modal-footer justify-content-center">
                                      <a href="../"type="button" class="btn btn-outline-success waves-effect">Retour à la boutique</a>
                                      
                                    </div>
                                  </div>
                                  <!--/.Content-->
                                </div>
                              </div>
                              <!-- Central Modal Medium Success-->



            </form>





            <div class="card-body card-body-cascade text-center" style="margin-top: -51px;">

              
                    <p>Veuillez nous transmettre les pièces suivantes : <span style="color:red;">  Rib, Kbis, Pièces d'identité </span>.</p>
                    <i class="fas fa-exclamation-circle"  style="font-size: 2em; color: red;">Nb:</i><p>Toute demande de partenariat sans ces pièces ne sera pas prise en compte.</p>
                   

            </div>





            <form action="upload.php" class="dropzone" style="margin-bottom: 65px;" >
            <div class="fallback">
              <input name="file" type="file" multiple />
              </div>
          </form>
            
          </div>
        </div>
    
      </section>
      <!--Section: Content-->
    
    </div>


<?php
include("inc/footer.php")
?>






  








