<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Vos Uploads EasyQuete</title>
  <!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/css/mdb.min.css" rel="stylesheet">
</head>

<body>



<div class="container">
  <div class="row">
    <div class="col-sm">
    </div>
    <div class="col-sm">
    <img src="../img/easyquete.png" class="img-fluid" alt="Responsive image" srcset="" >
    </div>
    <div class="col-sm">  
    </div>
  </div>
</div>

<div class="container nav" style="margin-left: 641px;margin-top: 30px;margin-bottom: 34px;">
<ul class="nav justify-content-center grey lighten-4 py-4" style="border-radius: 30px;">
  <li class="nav-item">
    <a class="nav-link active" href="index.html">Dashboard</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="view.php">Vos Uploads</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="vendeur.php">Vos demandes</a>
  </li>
</ul>
</div>


<?php
$folder="uploads";

if(is_dir($folder)){
    $handler = opendir ($folder);
    $output ="";

    while($files = readdir($handler)){
        if(!is_dir($files)){
            $output .= "<img src=\"uploads/{$files}\" width='600' height='500'>";
        }
    }
}

echo $output;
?>


<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/js/mdb.min.js"></script>
</body>

</html>